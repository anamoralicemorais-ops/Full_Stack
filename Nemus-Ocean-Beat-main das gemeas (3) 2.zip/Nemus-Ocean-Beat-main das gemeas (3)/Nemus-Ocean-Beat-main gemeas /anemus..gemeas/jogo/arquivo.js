let canvas=document.getElementById('canvas');
let ctx=canvas.getContext('2d');
 
// alga_esquerda
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='green';
ctx.fillRect(30,690,15,120);
ctx.fill();
ctx.closePath();

// alga_esquerda
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='darkgreen';
ctx.fillRect(38,740,15,100);
ctx.fill();
ctx.closePath();

// alga_esquerda
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#4BB748';
ctx.fillRect(53,730,15,200);
ctx.fill();
ctx.closePath();

// alga_esquerda
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#0B8F44';
ctx.fillRect(15,660,15,150);
ctx.fill();
ctx.closePath();


// alga_direita
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='green';
ctx.fillRect(1390,690,20,120);
ctx.fill();
ctx.closePath();

// alga_direita
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#4BB748';
ctx.fillRect(1375,660,20,150);
ctx.fill();
ctx.closePath();


// alga_direita
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#0B8F44';
ctx.fillRect(1355,680,20,130);
ctx.fill();
ctx.closePath();

// alga_direita
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#0F703A';
ctx.fillRect(1370,726,20,80);
ctx.fill();
ctx.closePath();

// alga_direita
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#0F703A';
ctx.fillRect(1415,655,15,180);
ctx.fill();
ctx.closePath();

// alga_direita
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#A9D5A0';
ctx.fillRect(1406,740,15,70);
ctx.fill();
ctx.closePath();


// alga do meio do lado direito
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#4BB748';
ctx.fillRect(980,707,15,85);
ctx.fill();
ctx.closePath();


// alga do meio do lado direito
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#20532A';
ctx.fillRect(1008,680,15,110);
ctx.fill();
ctx.closePath();


// alga do meio do lado direito
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#7CC472';
ctx.fillRect(994,730,20,60);
ctx.fill();
ctx.closePath();

// alga do meio do lado direito
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#157E43';
ctx.fillRect(970,650,15,150);
ctx.fill();
ctx.closePath();

// alga do meio do lado direito
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#20532A';
ctx.fillRect(980,750,15,75);
ctx.fill();
ctx.closePath();

// alga do meio do lado direito
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#2EAF4A';
ctx.fillRect(1021,650,15,160);
ctx.fill();
ctx.closePath();


// alga do meio do lado esquerdo
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#20532A';
ctx.fillRect(300,650,15,160);
ctx.fill();
ctx.closePath();

// alga do meio do lado esquerdo
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#7CC472';
ctx.fillRect(290,720,15,70);
ctx.fill();
ctx.closePath();


// alga do meio do lado esquerdo
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#0B8F44';
ctx.fillRect(278,680,15,120);
ctx.fill();
ctx.closePath();


// alga do meio do lado esquerdo
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#A9D5A0';
ctx.fillRect(314,680,15,120);
ctx.fill();
ctx.closePath();


// alga do meio do lado esquerdo
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#0B8F44';
ctx.fillRect(326,640,20,160);
ctx.fill();
ctx.closePath();


//  corpo da alga viva 
ctx.beginPath();
ctx.fillStyle='#91569E';
ctx.arc(550,300,55,1*Math.PI,0*Math.PI);
ctx.fill();
ctx.closePath();

// tentáculo da água viva n e do meio
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#D980CD';
ctx.fillRect(560,300,8,70);
ctx.fill();
ctx.closePath();

// tentáculo da água viva é do meio
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#D980CD';
ctx.fillRect(540,300,8,50);
ctx.fill();
ctx.closePath();


// tentáculo da água viva
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#D980CD';
ctx.fillRect(580,300,8,80);
ctx.fill();
ctx.closePath();


// tentáculo da água viva
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#D980CD';
ctx.fillRect(520,300,8,85);
ctx.fill();
ctx.closePath();


// tentáculo da água viva
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#D980CD';
ctx.fillRect(502,300,8,70);
ctx.fill();
ctx.closePath();


//  corpo da alga viva 2
ctx.beginPath();
ctx.fillStyle='#91569E';
ctx.arc(998,200,55,1*Math.PI,0*Math.PI);
ctx.fill();
ctx.closePath();

// tentáculo da água viva 2
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#D980CD';
ctx.fillRect(990,200,8,70);
ctx.fill();
ctx.closePath();

// tentáculo da água viva 2
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#D980CD';
ctx.fillRect(970,200,8,40);
ctx.fill();
ctx.closePath();

// tentáculo da água viva 2
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#D980CD';
ctx.fillRect(1008,200,8,60);
ctx.fill();
ctx.closePath();

// tentáculo da água viva 2
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#D980CD';
ctx.fillRect(955,200,8,90);
ctx.fill();
ctx.closePath();

// tentáculo da água viva 2
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle='#D980CD';
ctx.fillRect(1028,200,8,90);
ctx.fill();
ctx.closePath();

// casca da tartaruga 
ctx.beginPath();
ctx.fillStyle='#CFD597';
ctx.arc(600,700,80,1*Math.PI,0*Math.PI);
ctx.fill();
ctx.closePath();

// escama da casca da tartaruga 
ctx.beginPath();
ctx.fillStyle='#C19256';
ctx.arc(655,700,15,1*Math.PI,0*Math.PI);
ctx.fill();
ctx.closePath();

// escama da casca da tartaruga 
ctx.beginPath();
ctx.fillStyle='#C19256';
ctx.arc(620,640,15,0*Math.PI,2*Math.PI);
ctx.fill();
ctx.closePath();

// escama da casca da tartaruga 
ctx.beginPath();
ctx.fillStyle='#C19256';
ctx.arc(640,670,15,0*Math.PI,2*Math.PI);
ctx.fill();
ctx.closePath();

// escama da casca da tartaruga 
ctx.beginPath();
ctx.fillStyle='#C19256';
ctx.arc(606,670,15,0*Math.PI,2*Math.PI);
ctx.fill();
ctx.closePath();

// escama da casca da tartaruga 
ctx.beginPath();
ctx.fillStyle='#C19256';
ctx.arc(556,655,15,0*Math.PI,2*Math.PI);
ctx.fill();
ctx.closePath();

// escama da casca da tartaruga 
ctx.beginPath();
ctx.fillStyle='#C19256';
ctx.arc(563,685,15,0*Math.PI,2*Math.PI);
ctx.fill();
ctx.closePath();

// escama da casca da tartaruga 
ctx.beginPath();
ctx.fillStyle='#C19256';
ctx.arc(585,640,15,0*Math.PI,2*Math.PI);
ctx.fill();
ctx.closePath();


// escama da casca da tartaruga 
ctx.beginPath();
ctx.fillStyle='#C19256';
ctx.arc(534,700,15,1*Math.PI,0*Math.PI);
ctx.fill();
ctx.closePath();

// escama da casca da tartaruga 
ctx.beginPath();
ctx.fillStyle='#C19256';
ctx.arc(590,700,15,1*Math.PI,0*Math.PI);
ctx.fill();
ctx.closePath();

// escama da casca da tartaruga 
ctx.beginPath();
ctx.fillStyle='#C19256';
ctx.arc(622,700,15,1*Math.PI,0*Math.PI);
ctx.fill();
ctx.closePath();



// cabeça da tartaruga
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle= '#87A449';
ctx.arc(690,675,25,0,2*Math.PI);
ctx.fill();
ctx.closePath();

// olho da tartaruga
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle= 'black';
ctx.arc(696,665,6,0,2*Math.PI);
ctx.fill();
ctx.closePath();


// boca da tartaruga 
ctx.beginPath();
ctx.lineWidth=1;
ctx.strokeStyle='black';
ctx.arc(708,678,5,0*Math.PI,1*Math.PI);
ctx.stroke();
ctx.closePath();


// bolha da tartaruga
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle= '#C7EAFD';
ctx.arc(734,650,10,0,2*Math.PI);
ctx.fill();
ctx.closePath();

// bolha da tartaruga
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle= '#C7EAFD';
ctx.arc(745,620,15,0,2*Math.PI);
ctx.fill();
ctx.closePath();


// bolha da tartaruga
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle= '#C7EAFD';
ctx.arc(750,580,20,0,2*Math.PI);
ctx.fill();
ctx.closePath();

// pata da tartaruga 
ctx.beginPath();
ctx.lineWidth=1;
ctx.fillStyle= '#87A449';
ctx.arc(650,700,20,0*Math.PI,1*Math.PI);
ctx.fill();
ctx.closePath();


// pata da tartaruga 
ctx.beginPath();
ctx.lineWidth=1;
ctx.fillStyle= '#87A449';
ctx.arc(580,700,20,0*Math.PI,1*Math.PI);
ctx.fill();
ctx.closePath();

// rabo da tartaruga
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle= '#87A449';
ctx.fillRect(500,690,20,10);
ctx.fill();
ctx.closePath();


// areia 
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle= '#F6E29D';
ctx.fillRect(0,790,2000,20);
ctx.fill();
ctx.closePath();


// corpo do porco espinho
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle= '#F9A11D';
ctx.arc(340,115,37,0,2*Math.PI);
ctx.fill();
ctx.closePath();


 // olho do porco espinho
 ctx.beginPath();
 ctx.lineWidth=2;
 ctx.fillStyle= 'black';
 ctx.arc(315,108,6,0,2*Math.PI);
 ctx.fill();
 ctx.closePath();

 // boca do porco espinho
 ctx.beginPath();
 ctx.lineWidth=1;
 ctx.strokeStyle='black';
 ctx.arc(310,126,5,0*Math.PI,1*Math.PI);
 ctx.stroke();
 ctx.closePath();


// espinho do porco espinho 
ctx.beginPath();
ctx.lineWidth=5;
ctx.strokeStyle='#f9a11dac';
ctx.moveTo(330,120);
ctx.lineTo(310,150);
ctx.stroke();
ctx.closePath();
 
// espinho do porco espinho 
ctx.beginPath();
ctx.lineWidth=5;
ctx.strokeStyle='#f9a11dac';
ctx.moveTo(380,90);
ctx.lineTo(320,100);
ctx.stroke();
ctx.closePath();
 
// espinho do porco espinho 
ctx.beginPath();
ctx.lineWidth=5;
ctx.strokeStyle='#f9a11dac';
ctx.moveTo(360,120);
ctx.lineTo(380,140);
ctx.stroke();
ctx.closePath();
 
 
// espinho do porco espinho 
ctx.beginPath();
ctx.lineWidth=5;
ctx.strokeStyle='#f9a11dac';
ctx.moveTo(314,70);
ctx.lineTo(320,100);
ctx.stroke();
ctx.closePath();
 

// espinho do porco espinho 
ctx.beginPath();
ctx.lineWidth=5;
ctx.strokeStyle='#f9a11dac';
ctx.moveTo(354,66);
ctx.lineTo(350,100);
ctx.stroke();
ctx.closePath();


// espinho do porco espinho 
ctx.beginPath();
ctx.lineWidth=5;
ctx.strokeStyle='#f9a11dac';
ctx.moveTo(354,120);
ctx.lineTo(340,160);
ctx.stroke();
ctx.closePath();

// bolha do porco espinho
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle= '#C7EAFD';
ctx.arc(278,120,10,0,2*Math.PI);
ctx.fill();
ctx.closePath();

// bolha do porco espinho
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle= '#C7EAFD';
ctx.arc(268,90,15,0,2*Math.PI);
ctx.fill();
ctx.closePath();


// bolha do porco espinho
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle= '#C7EAFD';
ctx.arc(258,53,20,0,2*Math.PI);
ctx.fill();
ctx.closePath();


// corpo do porco espinho
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle= '#F9A11D';
ctx.arc(1190,445,42,0,2*Math.PI);
ctx.fill();
ctx.closePath();

// olho do porco espinho
 ctx.beginPath();
 ctx.lineWidth=2;
 ctx.fillStyle= 'black';
 ctx.arc(1215,440,8,0,2*Math.PI);
 ctx.fill();
 ctx.closePath();


 // boca do porco espinho
 ctx.beginPath();
 ctx.lineWidth=1;
 ctx.strokeStyle='black';
 ctx.arc(1220,460,5,0*Math.PI,1*Math.PI);
 ctx.stroke();
 ctx.closePath();

 // espinho do porco espinho 
ctx.beginPath();
ctx.lineWidth=5;
ctx.strokeStyle='#f9a11dac';
ctx.moveTo(1148,480);
ctx.lineTo(1170,440);
ctx.stroke();
ctx.closePath();

// espinho do porco espinho 
ctx.beginPath();
ctx.lineWidth=5;
ctx.strokeStyle='#f9a11dac';
ctx.moveTo(1148,406);
ctx.lineTo(1170,420);
ctx.stroke();
ctx.closePath();

 
// espinho do porco espinho 
ctx.beginPath();
ctx.lineWidth=5;
ctx.strokeStyle='#f9a11dac';
ctx.moveTo(1188,500); 
ctx.lineTo(1190,480); 
ctx.stroke();
ctx.closePath();


// espinho do porco espinho 
ctx.beginPath();
ctx.lineWidth=5;
ctx.strokeStyle='#f9a11dac';
ctx.moveTo(1198,390); 
ctx.lineTo(1190,480); 
ctx.stroke();
ctx.closePath();

// espinho do porco espinho 
ctx.beginPath();
ctx.lineWidth=5;
ctx.strokeStyle='#f9a11dac';
ctx.moveTo(1130,440); 
ctx.lineTo(1150,440); 
ctx.stroke();
ctx.closePath();

// bolha do porco espinho
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle= '#C7EAFD';
ctx.arc(1260,460,10,0,2*Math.PI);
ctx.fill();
ctx.closePath();

// bolha do porco espinho
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle= '#C7EAFD';
ctx.arc(1270,420,15,0,2*Math.PI);
ctx.fill();
ctx.closePath();


// bolha do porco espinho
ctx.beginPath();
ctx.lineWidth=2;
ctx.fillStyle= '#C7EAFD';
ctx.arc(1272,373,20,0,2*Math.PI);
ctx.fill();
ctx.closePath();


