var http = require("http");
var express = require("express");
var bodyParser = require("body-parser");
var mongodb = require("mongodb");
require("dotenv").config();

var MongoClient = mongodb.MongoClient;
var ObjectId = mongodb.ObjectId;

var app = express();
var porta = 80;
var uri = process.env.MONGO_URL;

app.use(express.static("./"));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

var client = new MongoClient(uri, { useNewUrlParser: true });
var dbo;
var usuarios;
var carros;

client.connect(function(erro) {
    if (erro) {
        console.log("Erro ao conectar no MongoDB:", erro.message);
        return;
    }

    dbo = client.db("lab10_carros");
    usuarios = dbo.collection("usuarios");
    carros = dbo.collection("carros");

    console.log("Conectado ao MongoDB");
});

function pagina(mensagem, link, textoLink) {
    return `
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Resposta</title>
            <link rel="stylesheet" href="/style.css">
        </head>
        <body>
            <main class="container">
                <h1>${mensagem}</h1>
                <a href="${link}">${textoLink}</a>
            </main>
        </body>
        </html>
    `;
}

function input(nome, valor) {
    if (valor === undefined || valor === null) {
        valor = "";
    }

    return String(valor)
        .replaceAll("&", "&amp;")
        .replaceAll('"', "&quot;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;");
}

app.get("/", function(req, resp) {
    resp.redirect("/login_usuario.html");
});

app.post("/cadastrar_usuario", function(req, resp) {
    var data = {
        db_nome: req.body.nome,
        db_login: req.body.login,
        db_senha: req.body.senha
    };

    usuarios.insertOne(data, function(erro) {
        if (erro) {
            resp.send(pagina("Erro ao cadastrar usuario", "/cadastro_usuario.html", "Voltar"));
        } else {
            resp.send(pagina("Usuario cadastrado", "/login_usuario.html", "Fazer login"));
        }
    });
});

app.post("/logar_usuario", function(req, resp) {
    var data = {
        db_login: req.body.login,
        db_senha: req.body.senha
    };

    usuarios.find(data).toArray(function(erro, resultado) {
        if (erro || resultado.length == 0) {
            resp.send(pagina("Login ou senha invalidos", "/login_usuario.html", "Tentar novamente"));
        } else {
            resp.redirect("/gerencia_carros");
        }
    });
});

app.get("/carros", function(req, resp) {
    carros.find({
        db_marca: { $exists: true, $ne: "" },
        db_modelo: { $exists: true, $ne: "" }
    }).toArray(function(erro, resultado) {
        if (erro) {
            resp.send(pagina("Erro ao buscar carros", "/login_usuario.html", "Voltar"));
            return;
        }

        var linhas = "";

        for (var i = 0; i < resultado.length; i++) {
            linhas += `
                <tr>
                    <td>${input(resultado[i].db_marca)}</td>
                    <td>${input(resultado[i].db_modelo)}</td>
                    <td>${input(resultado[i].db_ano)}</td>
                    <td>${input(resultado[i].db_qtde_disponivel)}</td>
                    <td>
                        <form action="/carros/vender/${resultado[i]._id}" method="post">
                            <button type="submit">Vender</button>
                        </form>
                    </td>
                </tr>
            `;
        }

        if (linhas == "") {
            linhas = `
                <tr>
                    <td colspan="5">Nenhum carro cadastrado.</td>
                </tr>
            `;
        }

        resp.send(`
            <!DOCTYPE html>
            <html lang="pt-BR">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Carros Disponiveis</title>
                <link rel="stylesheet" href="/style.css">
            </head>
            <body>
                <main class="container grande">
                    <h1>Carros disponiveis</h1>
                    <table>
                        <tr>
                            <th>Marca</th>
                            <th>Modelo</th>
                            <th>Ano</th>
                            <th>Quantidade</th>
                            <th>Acao</th>
                        </tr>
                        ${linhas}
                    </table>
                </main>
            </body>
            </html>
        `);
    });
});

app.get("/gerencia_carros", function(req, resp) {
    carros.find({
        db_marca: { $exists: true, $ne: "" },
        db_modelo: { $exists: true, $ne: "" }
    }).toArray(function(erro, resultado) {
        if (erro) {
            resp.send(pagina("Erro ao buscar carros", "/login_usuario.html", "Voltar"));
            return;
        }

        var linhas = "";

        for (var i = 0; i < resultado.length; i++) {
            linhas += `
                <tr>
                    <form action="/carros/atualizar/${resultado[i]._id}" method="post">
                        <td><input type="text" name="marca" value="${input(resultado[i].db_marca)}" required></td>
                        <td><input type="text" name="modelo" value="${input(resultado[i].db_modelo)}" required></td>
                        <td><input type="number" name="ano" value="${input(resultado[i].db_ano)}" required></td>
                        <td><input type="number" name="qtde_disponivel" value="${input(resultado[i].db_qtde_disponivel)}" required></td>
                        <td>
                            <button type="submit">Atualizar</button>
                    </form>
                            <form action="/carros/remover/${resultado[i]._id}" method="post">
                                <button type="submit">Remover</button>
                            </form>
                        </td>
                </tr>
            `;
        }

        if (linhas == "") {
            linhas = `
                <tr>
                    <td colspan="5">Nenhum carro cadastrado.</td>
                </tr>
            `;
        }

        resp.send(`
            <!DOCTYPE html>
            <html lang="pt-BR">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Gerencia de Carros</title>
                <link rel="stylesheet" href="/style.css">
            </head>
            <body>
                <main class="container grande">
                    <h1>Gerencia de carros</h1>

                    <form action="/carros/cadastrar" method="post" class="form-grid">
                        <input type="text" name="marca" placeholder="Marca" required>
                        <input type="text" name="modelo" placeholder="Modelo" required>
                        <input type="number" name="ano" placeholder="Ano" required>
                        <input type="number" name="qtde_disponivel" placeholder="Quantidade" required>
                        <button type="submit">Cadastrar carro</button>
                    </form>

                    <table>
                        <tr>
                            <th>Marca</th>
                            <th>Modelo</th>
                            <th>Ano</th>
                            <th>Quantidade</th>
                            <th>Acoes</th>
                        </tr>
                        ${linhas}
                    </table>
                </main>
            </body>
            </html>
        `);
    });
});

app.post("/carros/cadastrar", function(req, resp) {
    if (!req.body.marca || !req.body.modelo || !req.body.ano || !req.body.qtde_disponivel) {
        resp.send(pagina("Preencha todos os campos do carro", "/gerencia_carros", "Voltar"));
        return;
    }

    var data = {
        db_marca: req.body.marca,
        db_modelo: req.body.modelo,
        db_ano: Number(req.body.ano),
        db_qtde_disponivel: Number(req.body.qtde_disponivel)
    };

    carros.insertOne(data, function(erro) {
        if (erro) {
            resp.send(pagina("Erro ao cadastrar carro", "/gerencia_carros", "Voltar"));
        } else {
            resp.redirect("/gerencia_carros");
        }
    });
});

app.post("/carros/atualizar/:id", function(req, resp) {
    var data = {
        _id: new ObjectId(req.params.id)
    };

    var newData = {
        $set: {
            db_marca: req.body.marca,
            db_modelo: req.body.modelo,
            db_ano: Number(req.body.ano),
            db_qtde_disponivel: Number(req.body.qtde_disponivel)
        }
    };

    carros.updateOne(data, newData, function(erro) {
        if (erro) {
            resp.send(pagina("Erro ao atualizar carro", "/gerencia_carros", "Voltar"));
        } else {
            resp.redirect("/gerencia_carros");
        }
    });
});

app.post("/carros/remover/:id", function(req, resp) {
    var data = {
        _id: new ObjectId(req.params.id)
    };

    carros.deleteOne(data, function(erro) {
        if (erro) {
            resp.send(pagina("Erro ao remover carro", "/gerencia_carros", "Voltar"));
        } else {
            resp.redirect("/gerencia_carros");
        }
    });
});

app.post("/carros/vender/:id", function(req, resp) {
    var data = {
        _id: new ObjectId(req.params.id)
    };

    carros.find(data).toArray(function(erro, resultado) {
        if (erro || resultado.length == 0) {
            resp.send(pagina("Carro nao encontrado", "/carros", "Voltar"));
        } else if (resultado[0].db_qtde_disponivel <= 0) {
            resp.redirect("/carros");
        } else {
            var newData = {
                $set: {
                    db_qtde_disponivel: resultado[0].db_qtde_disponivel - 1
                }
            };

            carros.updateOne(data, newData, function() {
                resp.redirect("/carros");
            });
        }
    });
});

var server = http.createServer(app);
server.listen(porta);

console.log("Servidor rodando ...");
