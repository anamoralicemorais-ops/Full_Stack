var http = require("http");
var express = require("express");
var bodyParser = require("body-parser");
var mongodb = require("mongodb");
var path = require("path");
require("dotenv").config({ path: path.join(__dirname, ".env") });

var MongoClient = mongodb.MongoClient;
var ObjectId = mongodb.ObjectId;

var app = express();
var porta = 80;
var raizSite = path.join(__dirname, "..", "..");
var uri = process.env.MONGO_URL;

app.use(express.static(raizSite));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.set("view engine", "ejs");
app.set("views", "./views");

var client = new MongoClient(uri, { useNewUrlParser: true });
var dbo;
var usuarios;
var posts;
var carros;

client.connect(function(erro) {
    if (erro) {
        console.log("Erro ao conectar no MongoDB:", erro.message);
        return;
    }

    dbo = client.db("lab10carros");
    usuarios = dbo.collection("usuarios");
    posts = dbo.collection("posts");
    carros = dbo.collection("carros");

    console.log("Conectado ao MongoDB Atlas");
});

function enviarHome(req, res) {
    res.sendFile(path.join(raizSite, "Lab1", "index.html"));
}

function enviarProjetos(req, res) {
    res.sendFile(path.join(raizSite, "Lab2", "projects.html"));
}

app.get("/", enviarProjetos);
app.get("/Home.html", enviarHome);
app.get("/home.html", enviarHome);
app.get("/index.html", enviarHome);

app.get("/Project.html", enviarProjetos);
app.get("/project.html", enviarProjetos);
app.get("/Projects.html", enviarProjetos);
app.get("/projects.html", enviarProjetos);

app.get("/cadastra", function(req, res) {
    res.sendFile(path.join(raizSite, "Lab8", "Cadastro.html"));
});

app.get("/login", function(req, res) {
    res.sendFile(path.join(raizSite, "Lab8", "Login.html"));
});

app.post("/cadastra", function(req, res) {
    res.redirect(307, "/cadastrar_usuario");
});

app.post("/login", function(req, res) {
    res.redirect(307, "/logar_usuario");
});

app.get("/cadastro_usuario", function(req, res) {
    res.sendFile(path.join(raizSite, "Lab10", "cadastro_usuario.html"));
});

app.get("/login_usuario", function(req, res) {
    res.sendFile(path.join(raizSite, "Lab10", "login_usuario.html"));
});

app.post("/cadastrar_usuario", function(req, res) {
    var data = {
        db_nome: req.body.nome,
        db_login: req.body.login,
        db_senha: req.body.senha
    };

    usuarios.insertOne(data, function(erro) {
        console.log(erro);
        if (erro) {
            res.render("resposta_usuario", { resposta: "Erro ao cadastrar usuario!" });
        } else {
            res.render("resposta_usuario", { resposta: "Usuario cadastrado com sucesso!" });
        }
    });
});

app.post("/usuarios/cadastrar", function(req, res) {
    res.redirect(307, "/cadastrar_usuario");
});

app.post("/logar_usuario", function(req, res) {
    var data = {
        db_login: req.body.login,
        db_senha: req.body.senha
    };

    usuarios.find(data).toArray(function(erro, items) {
        console.log(items);
        if (erro) {
            res.render("resposta_usuario", { resposta: "Erro ao logar usuario!" });
        } else if (items.length == 0) {
            res.render("resposta_usuario", { resposta: "Usuario/senha nao encontrado!" });
        } else {
            res.render("resposta_usuario", { resposta: "Usuario logado com sucesso!" });
        }
    });
});

app.post("/usuarios/login", function(req, res) {
    res.redirect(307, "/logar_usuario");
});

app.post("/atualizar_usuario", function(req, res) {
    var data = {
        db_login: req.body.login,
        db_senha: req.body.senha
    };
    var newData = {
        $set: {
            db_senha: req.body.novasenha
        }
    };

    usuarios.updateOne(data, newData, function(erro, result) {
        console.log(result);
        if (erro) {
            res.render("resposta_usuario", { resposta: "Erro ao atualizar usuario!" });
        } else if (result.modifiedCount == 0) {
            res.render("resposta_usuario", { resposta: "Usuario/senha nao encontrado!" });
        } else {
            res.render("resposta_usuario", { resposta: "Usuario atualizado com sucesso!" });
        }
    });
});

app.post("/remover_usuario", function(req, res) {
    var data = {
        db_login: req.body.login,
        db_senha: req.body.senha
    };

    usuarios.deleteOne(data, function(erro, result) {
        console.log(result);
        if (erro) {
            res.render("resposta_usuario", { resposta: "Erro ao remover usuario!" });
        } else if (result.deletedCount == 0) {
            res.render("resposta_usuario", { resposta: "Usuario/senha nao encontrado!" });
        } else {
            res.render("resposta_usuario", { resposta: "Usuario removido com sucesso!" });
        }
    });
});

app.get("/blog", function(req, res) {
    posts.find().sort({ _id: -1 }).toArray(function(erro, items) {
        if (erro) {
            res.render("resposta", {
                titulo: "Erro",
                mensagem: "Erro ao buscar posts."
            });
        } else {
            res.render("blog", { posts: items });
        }
    });
});

app.get("/cadastrar_post", function(req, res) {
    res.sendFile(path.join(raizSite, "Lab9", "cadastrar_post.html"));
});

app.post("/cadastrar_post", function(req, res) {
    var data = {
        db_titulo: req.body.titulo,
        db_resumo: req.body.resumo,
        db_conteudo: req.body.conteudo
    };

    posts.insertOne(data, function(erro) {
        if (erro) {
            res.render("resposta", {
                titulo: "Erro",
                mensagem: "Erro ao cadastrar post."
            });
        } else {
            res.render("resposta", {
                titulo: "Post cadastrado",
                mensagem: "O post foi cadastrado com sucesso."
            });
        }
    });
});

app.get("/carros", function(req, res) {
    carros.find().sort({ db_marca: 1, db_modelo: 1 }).toArray(function(erro, items) {
        if (erro) {
            res.render("resposta", {
                titulo: "Erro",
                mensagem: "Erro ao buscar carros."
            });
        } else {
            res.render("carros", { carros: items });
        }
    });
});

app.get("/gerencia_carros", function(req, res) {
    carros.find().sort({ db_marca: 1, db_modelo: 1 }).toArray(function(erro, items) {
        if (erro) {
            res.render("resposta", {
                titulo: "Erro",
                mensagem: "Erro ao buscar carros."
            });
        } else {
            res.render("gerencia_carros", { carros: items });
        }
    });
});

app.post("/carros/cadastrar", function(req, res) {
    var data = {
        db_marca: req.body.marca,
        db_modelo: req.body.modelo,
        db_ano: Number(req.body.ano),
        db_qtde_disponivel: Number(req.body.qtde_disponivel)
    };

    carros.insertOne(data, function(erro) {
        console.log(erro);
        res.redirect("/gerencia_carros");
    });
});

app.post("/carros/remover/:id", function(req, res) {
    var data = {
        _id: new ObjectId(req.params.id)
    };

    carros.deleteOne(data, function(erro, result) {
        console.log(result);
        res.redirect("/gerencia_carros");
    });
});

app.post("/carros/atualizar/:id", function(req, res) {
    var data = {
        _id: new ObjectId(req.params.id)
    };
    var newData = {
        $set: {
            db_marca: req.body.marca,
            db_modelo: req.body.modelo,
            db_ano: Number(req.body.ano),
            db_qtde_disponivel: Number(req.body.qtde_disponivel)
        }
    };

    carros.updateOne(data, newData, function(erro, result) {
        console.log(result);
        res.redirect("/gerencia_carros");
    });
});

app.post("/carros/vender/:id", function(req, res) {
    var data = {
        _id: new ObjectId(req.params.id)
    };

    carros.find(data).toArray(function(erro, items) {
        if (erro || items.length == 0 || items[0].db_qtde_disponivel <= 0) {
            res.redirect("/carros");
        } else {
            var newData = {
                $set: {
                    db_qtde_disponivel: items[0].db_qtde_disponivel - 1
                }
            };

            carros.updateOne(data, newData, function() {
                res.redirect("/carros");
            });
        }
    });
});

var server = http.createServer(app);
server.listen(porta);

console.log("Servidor rodando ...");
