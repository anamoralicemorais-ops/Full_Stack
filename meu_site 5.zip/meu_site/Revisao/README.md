# Revisao estilo Lab 10

Use este modelo quando o teste pedir um CRUD parecido com o Lab 10.

## teste 

No teste, se vier tudo vazio, faca nesta ordem:

```bash
mkdir revisao
cd revisao
npm init -y
npm install express ejs body-parser mongodb@4.12 dotenv
mkdir public
mkdir views
touch servidor.js
touch .env
touch public/style.css
touch public/cadastro_item.html
touch views/itens.ejs
touch views/resposta.ejs
```

No `.env`, coloque o mesmo link do MongoDB Atlas:

```env
MONGO_URL=mongodb+srv://usuario:senha@cluster.mongodb.net/
```

Depois copie o modelo do `servidor.js`, do HTML e dos EJS.

O que voce precisa trocar:

```text
meubanco              -> nome do banco do teste
itens                 -> nome da collection
item                  -> nome singular do tema
itens                 -> nome plural do tema
db_nome               -> primeiro campo principal
db_descricao          -> segundo campo principal
db_ano                -> campo numerico, se existir
db_qtde_disponivel    -> campo de quantidade, estoque ou vagas
baixar_quantidade     -> nome da acao extra
```

Exemplo para livros:

```text
meubanco              -> revisao_biblioteca
itens                 -> livros
item                  -> livro
db_nome               -> db_titulo
db_descricao          -> db_autor
db_ano                -> db_ano
db_qtde_disponivel    -> db_qtde_disponivel
baixar_quantidade     -> emprestar_livro
```

Exemplo para carros:

```text
meubanco              -> revisao_carros
itens                 -> carros
item                  -> carro
db_nome               -> db_marca
db_descricao          -> db_modelo
db_ano                -> db_ano
db_qtde_disponivel    -> db_qtde_disponivel
baixar_quantidade     -> vender_carro
```

Exemplo para produtos:

```text
meubanco              -> revisao_produtos
itens                 -> produtos
item                  -> produto
db_nome               -> db_nome
db_descricao          -> db_categoria
db_ano                -> db_preco
db_qtde_disponivel    -> db_estoque
baixar_quantidade     -> vender_produto
```

Depois rode:

```bash
sudo node servidor.js
```

Abra:

```text
http://localhost/itens
http://localhost/cadastro_item
```

Ele ja vem com:

- servidor Express
- body-parser
- EJS
- MongoDB com driver `mongodb@4.12`
- Create, Read, Update, Delete
- acao extra de diminuir quantidade

## O que trocar para outro tema

Exemplo: se o tema for biblioteca, troque:

```text
item       -> livro
itens      -> livros
meubanco   -> revisao_biblioteca
db_nome    -> db_titulo
db_descricao -> db_autor
```

Se o tema for carros:

```text
item       -> carro
itens      -> carros
meubanco   -> revisao_carros
db_nome    -> db_marca
db_descricao -> db_modelo
```

## Como rodar

Se voce estiver usando esta pasta pronta, rode:

```bash
cd ~/Downloads/meu_site/Revisao
npm install
sudo npm start
```

Depois abra:

```text
http://localhost/itens
http://localhost/cadastro_item
```

## Caminho completo para fazer no teste

No teste, voce provavelmente vai estar em outro computador e vai precisar criar tudo do zero.

### 1. Criar e entrar na pasta

Escolha um lugar facil, por exemplo a area de trabalho ou downloads.

```bash
mkdir revisao
cd revisao
```

Se o professor ja criar uma pasta para voce, entre nela:

```bash
cd caminho/da/pasta
```

Para confirmar que voce esta na pasta certa:

```bash
pwd
```

### 2. Criar o projeto Node

```bash
npm init -y
```

Isso cria o arquivo:

```text
package.json
```

### 3. Instalar os pacotes

Use os pacotes no mesmo estilo das aulas:

```bash
npm install express ejs body-parser mongodb@4.12 dotenv
```

### 4. Criar as pastas

```bash
mkdir public
mkdir views
```

A estrutura fica assim:

```text
revisao/
  servidor.js
  package.json
  .env
  public/
    style.css
    cadastro_item.html
  views/
    itens.ejs
    resposta.ejs
```

### 5. Criar o arquivo `.env`

Crie um arquivo chamado:

```text
.env
```

Dentro dele coloque o link do MongoDB:

```env
MONGO_URL=mongodb+srv://usuario:senha@cluster.mongodb.net/
```

Pode usar o mesmo link do MongoDB Atlas dos labs.

### 6. Criar o `servidor.js`

No servidor, a parte principal sempre segue esta ordem:

```js
var http = require("http");
var express = require("express");
var bodyParser = require("body-parser");
var mongodb = require("mongodb");
require("dotenv").config();

var MongoClient = mongodb.MongoClient;
var ObjectId = mongodb.ObjectId;

var app = express();
var porta = 80;
var uri = process.env.MONGO_URL;

app.use(express.static("./public"));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.set("view engine", "ejs");
app.set("views", "./views");
```

Depois vem a conexao com o banco:

```js
var client = new MongoClient(uri, { useNewUrlParser: true });
var dbo;
var itens;

client.connect(function(erro) {
    if (erro) {
        console.log("Erro ao conectar no MongoDB:", erro.message);
        return;
    }

    dbo = client.db("meubanco");
    itens = dbo.collection("itens");

    console.log("Conectado ao MongoDB");
});
```

Troque:

```text
meubanco -> nome do banco do teste
itens    -> nome da collection do teste
```

### 7. Criar as rotas principais

As rotas basicas do CRUD sao:

```text
GET  /
GET  /cadastro_item
GET  /itens
POST /cadastrar_item
POST /atualizar_item/:id
POST /remover_item/:id
POST /baixar_quantidade/:id
```

Se o tema for livros, voce pode trocar para:

```text
GET  /livros
POST /cadastrar_livro
POST /atualizar_livro/:id
POST /remover_livro/:id
POST /emprestar_livro/:id
```

Estrutura pronta do CRUD para colocar depois da conexao com o banco:

```js
app.get("/", function(req, resp) {
    resp.redirect("/itens");
});

app.get("/cadastro_item", function(req, resp) {
    resp.sendFile(__dirname + "/public/cadastro_item.html");
});

app.get("/itens", function(req, resp) {
    itens.find().toArray(function(erro, resultado) {
        if (erro) {
            resp.render("resposta", { resposta: "Erro ao buscar itens!" });
        } else {
            resp.render("itens", { itens: resultado });
        }
    });
});
```

Create:

```js
app.post("/cadastrar_item", function(req, resp) {
    var data = {
        db_nome: req.body.nome,
        db_descricao: req.body.descricao,
        db_ano: Number(req.body.ano),
        db_qtde_disponivel: Number(req.body.qtde_disponivel)
    };

    itens.insertOne(data, function(erro) {
        console.log(erro);
        if (erro) {
            resp.render("resposta", { resposta: "Erro ao cadastrar item!" });
        } else {
            resp.redirect("/itens");
        }
    });
});
```

Update:

```js
app.post("/atualizar_item/:id", function(req, resp) {
    var data = {
        _id: new ObjectId(req.params.id)
    };

    var newData = {
        $set: {
            db_nome: req.body.nome,
            db_descricao: req.body.descricao,
            db_ano: Number(req.body.ano),
            db_qtde_disponivel: Number(req.body.qtde_disponivel)
        }
    };

    itens.updateOne(data, newData, function(erro, resultado) {
        console.log(resultado);
        if (erro) {
            resp.render("resposta", { resposta: "Erro ao atualizar item!" });
        } else {
            resp.redirect("/itens");
        }
    });
});
```

Delete:

```js
app.post("/remover_item/:id", function(req, resp) {
    var data = {
        _id: new ObjectId(req.params.id)
    };

    itens.deleteOne(data, function(erro, resultado) {
        console.log(resultado);
        if (erro) {
            resp.render("resposta", { resposta: "Erro ao remover item!" });
        } else {
            resp.redirect("/itens");
        }
    });
});
```

Acao extra para diminuir quantidade:

```js
app.post("/baixar_quantidade/:id", function(req, resp) {
    var data = {
        _id: new ObjectId(req.params.id)
    };

    itens.find(data).toArray(function(erro, resultado) {
        if (erro || resultado.length == 0) {
            resp.render("resposta", { resposta: "Item nao encontrado!" });
        } else if (resultado[0].db_qtde_disponivel <= 0) {
            resp.redirect("/itens");
        } else {
            var newData = {
                $set: {
                    db_qtde_disponivel: resultado[0].db_qtde_disponivel - 1
                }
            };

            itens.updateOne(data, newData, function() {
                resp.redirect("/itens");
            });
        }
    });
});
```

No final do `servidor.js`, ligue o servidor:

```js
var server = http.createServer(app);
server.listen(porta);

console.log("Servidor rodando ...");
```

### 8. Rodar o servidor

Na pasta do teste:

```bash
sudo node servidor.js
```

Ou, se voce colocou `"start": "node servidor.js"` no `package.json`:

```bash
sudo npm start
```

O `sudo` e usado porque a porta `80` normalmente precisa de permissao.

### 9. Abrir no navegador

Se voce manteve o modelo generico:

```text
http://localhost/itens
http://localhost/cadastro_item
```

Se voce trocou para livros:

```text
http://localhost/livros
http://localhost/cadastro_livro
```

### 10. Se der erro comum

Se aparecer erro de modulo nao encontrado:

```bash
npm install
```

Se aparecer erro de permissao na porta:

```bash
sudo node servidor.js
```

Se nao conectar no MongoDB:

- confira se o `.env` esta na mesma pasta do `servidor.js`
- confira se esta escrito `MONGO_URL=...`
- confira se o IP `0.0.0.0/0` esta liberado no MongoDB Atlas
- confira se usuario e senha do link estao certos

## MongoDB

Voce pode usar o mesmo MongoDB Atlas dos labs.

Copie seu link para um arquivo `.env`:

```env
MONGO_URL=mongodb+srv://usuario:senha@cluster.mongodb.net/
```

O banco escolhido fica no `servidor.js`:

```js
dbo = client.db("meubanco");
```

## Observacao sobre Lab 10 e login

No Lab 10 existe `cadastro_usuario.html` porque ele tem uma parte de usuario antes da parte de carros:

```text
cadastro_usuario.html -> POST /cadastrar_usuario
login_usuario.html    -> POST /logar_usuario
gerencia_carros       -> CRUD de carros
carros                -> lista/venda de carros
```

Na revisao de biblioteca ou de CRUD simples, normalmente nao precisa de usuario. Se o enunciado pedir apenas livros, produtos, carros etc., faca somente as rotas do tema:

```text
GET  /cadastro_livro
POST /cadastrar_livro
GET  /livros
POST /atualizar_livro/:id
POST /remover_livro/:id
POST /emprestar_livro/:id
```

Para ligar um formulario HTML no servidor, o `action` do HTML precisa ter o mesmo nome da rota no `servidor.js`.

Exemplo no HTML:

```html
<form action="/cadastrar_usuario" method="post">
```

Exemplo no servidor:

```js
app.post("/cadastrar_usuario", function(req, resp) {
    var data = {
        db_nome: req.body.nome,
        db_login: req.body.login,
        db_senha: req.body.senha
    };

    usuarios.insertOne(data, function(erro) {
        if (erro) {
            resp.send("Erro ao cadastrar usuario");
        } else {
            resp.send("Usuario cadastrado");
        }
    });
});
```

Tambem precisa criar a collection antes:

```js
var usuarios;

client.connect(function(erro) {
    dbo = client.db("nome_do_banco");
    usuarios = dbo.collection("usuarios");
});
```

Resumo:

```text
HTML form action="/cadastrar_usuario"
             |
             v
servidor app.post("/cadastrar_usuario")
             |
             v
MongoDB usuarios.insertOne(...)
```
