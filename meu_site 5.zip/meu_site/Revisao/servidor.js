var http = require("http");
var express = require("express");
var bodyParser = require("body-parser");
var mongodb = require("mongodb");
require("dotenv").config();

var MongoClient = mongodb.MongoClient;
var ObjectId = mongodb.ObjectId;

var app = express();
var porta = 80;
var uri = process.env.MONGO_URL;

app.use(express.static("./public"));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.set("view engine", "ejs");
app.set("views", "./views");

var client = new MongoClient(uri, { useNewUrlParser: true });
var dbo;
var itens;

client.connect(function(erro) {
    if (erro) {
        console.log("Erro ao conectar no MongoDB:", erro.message);
        return;
    }

    // TROQUE "meubanco" pelo nome do banco do teste.
    dbo = client.db("meubanco");

    // TROQUE "itens" pelo nome da collection do tema.
    itens = dbo.collection("itens");

    console.log("Conectado ao MongoDB");
});

app.get("/", function(req, resp) {
    resp.redirect("/itens");
});

app.get("/cadastro_item", function(req, resp) {
    resp.sendFile(__dirname + "/public/cadastro_item.html");
});

app.get("/itens", function(req, resp) {
    itens.find().toArray(function(erro, resultado) {
        if (erro) {
            resp.render("resposta", { resposta: "Erro ao buscar itens!" });
        } else {
            resp.render("itens", { itens: resultado });
        }
    });
});

app.post("/cadastrar_item", function(req, resp) {
    var data = {
        db_nome: req.body.nome,
        db_descricao: req.body.descricao,
        db_ano: Number(req.body.ano),
        db_qtde_disponivel: Number(req.body.qtde_disponivel)
    };

    itens.insertOne(data, function(erro) {
        console.log(erro);
        if (erro) {
            resp.render("resposta", { resposta: "Erro ao cadastrar item!" });
        } else {
            resp.redirect("/itens");
        }
    });
});

app.post("/atualizar_item/:id", function(req, resp) {
    var data = {
        _id: new ObjectId(req.params.id)
    };

    var newData = {
        $set: {
            db_nome: req.body.nome,
            db_descricao: req.body.descricao,
            db_ano: Number(req.body.ano),
            db_qtde_disponivel: Number(req.body.qtde_disponivel)
        }
    };

    itens.updateOne(data, newData, function(erro, resultado) {
        console.log(resultado);
        if (erro) {
            resp.render("resposta", { resposta: "Erro ao atualizar item!" });
        } else {
            resp.redirect("/itens");
        }
    });
});

app.post("/remover_item/:id", function(req, resp) {
    var data = {
        _id: new ObjectId(req.params.id)
    };

    itens.deleteOne(data, function(erro, resultado) {
        console.log(resultado);
        if (erro) {
            resp.render("resposta", { resposta: "Erro ao remover item!" });
        } else {
            resp.redirect("/itens");
        }
    });
});

app.post("/baixar_quantidade/:id", function(req, resp) {
    var data = {
        _id: new ObjectId(req.params.id)
    };

    itens.find(data).toArray(function(erro, resultado) {
        if (erro || resultado.length == 0) {
            resp.render("resposta", { resposta: "Item nao encontrado!" });
        } else if (resultado[0].db_qtde_disponivel <= 0) {
            resp.redirect("/itens");
        } else {
            var newData = {
                $set: {
                    db_qtde_disponivel: resultado[0].db_qtde_disponivel - 1
                }
            };

            itens.updateOne(data, newData, function() {
                resp.redirect("/itens");
            });
        }
    });
});

var server = http.createServer(app);
server.listen(porta);

console.log("Servidor rodando ...");
