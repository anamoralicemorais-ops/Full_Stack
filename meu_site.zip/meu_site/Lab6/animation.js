let canvas = document.getElementById("canvas");
let ctx = canvas.getContext("2d");

let bola = {
    x: 150,
    y: 150,
    largura: 80,
    altura: 80,
    img: new Image(),
    desenha: function() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(
            this.img,
            this.x - this.largura / 2,
            this.y - this.altura / 2,
            this.largura,
            this.altura
        );
    }
};

bola.img.src = "bola.jpg";
bola.img.onload = function() {
    bola.desenha();
};

canvas.addEventListener("mousemove", function(evento) {
    let rect = canvas.getBoundingClientRect();
    let xMouse = evento.clientX - rect.left;
    let yMouse = evento.clientY - rect.top;

    let metadeLargura = bola.largura / 2;
    let metadeAltura = bola.altura / 2;

    if (xMouse < metadeLargura) {
        bola.x = metadeLargura;
    } else if (xMouse > canvas.width - metadeLargura) {
        bola.x = canvas.width - metadeLargura;
    } else {
        bola.x = xMouse;
    }

    if (yMouse < metadeAltura) {
        bola.y = metadeAltura;
    } else if (yMouse > canvas.height - metadeAltura) {
        bola.y = canvas.height - metadeAltura;
    } else {
        bola.y = yMouse;
    }

    bola.desenha();
});
