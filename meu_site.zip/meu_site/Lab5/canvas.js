let canvas = document.getElementById("canvas");
let casa = document.getElementById("casa");
let ctx = canvas.getContext("2d");
let ctxCasa = casa.getContext("2d");
let ctxAtual = ctx;

function usar_canvas(contexto) {
    ctxAtual = contexto;
}

function desenhar_quadrado(x, y, largura, altura, cor) {
    ctxAtual.fillStyle = cor;
    ctxAtual.fillRect(x, y, largura, altura);
}

function desenhar_linha(xInicial, yInicial, xFinal, yFinal, cor, largura) {
    ctxAtual.beginPath();
    ctxAtual.moveTo(xInicial, yInicial);
    ctxAtual.lineTo(xFinal, yFinal);
    ctxAtual.strokeStyle = cor;
    ctxAtual.lineWidth = largura;
    ctxAtual.stroke();
    ctxAtual.closePath();
}

function desenhar_arco(x, y, raio, inicio, fim, cor, largura, preencher) {
    ctxAtual.beginPath();
    ctxAtual.arc(x, y, raio, inicio, fim);

    if (preencher) {
        ctxAtual.fillStyle = cor;
        ctxAtual.fill();
    } else {
        ctxAtual.strokeStyle = cor;
        ctxAtual.lineWidth = largura;
        ctxAtual.stroke();
    }

    ctxAtual.closePath();
}

function escrever(texto, x, y, cor, tamanho) {
    ctxAtual.fillStyle = cor;
    ctxAtual.font = tamanho + "px Arial";
    ctxAtual.fillText(texto, x, y);
}

function desenhar_triangulo(x1, y1, x2, y2, x3, y3, cor) {
    ctxAtual.beginPath();
    ctxAtual.moveTo(x1, y1);
    ctxAtual.lineTo(x2, y2);
    ctxAtual.lineTo(x3, y3);
    ctxAtual.closePath();
    ctxAtual.fillStyle = cor;
    ctxAtual.fill();
}

function desenhar_modelo_canvas() {
    usar_canvas(ctx);

    desenhar_quadrado(0, 0, 50, 50, "blue");
    desenhar_quadrado(250, 0, 50, 50, "red");
    desenhar_quadrado(0, 120, 30, 60, "cyan");
    desenhar_quadrado(270, 135, 30, 30, "cyan");
    desenhar_quadrado(110, 150, 40, 40, "red");
    desenhar_quadrado(0, 240, 30, 60, "yellow");
    desenhar_quadrado(30, 270, 30, 30, "yellow");
    desenhar_quadrado(270, 240, 30, 60, "black");
    desenhar_quadrado(240, 270, 30, 30, "black");

    escrever("Canvas", 115, 48, "#555555", 24);

    desenhar_linha(50, 50, 150, 150, "blue", 2);
    desenhar_linha(250, 50, 150, 150, "red", 2);
    desenhar_linha(0, 150, 300, 150, "green", 2);
    desenhar_linha(150, 150, 150, 245, "#555555", 2);

    desenhar_arco(150, 150, 82, Math.PI, 0, "green", 2, false);
    desenhar_arco(150, 150, 60, Math.PI, 0, "green", 2, false);
    desenhar_arco(150, 300, 80, Math.PI, 0, "green", 2, false);

    desenhar_arco(150, 300, 40, Math.PI, 0, "cyan", 2, true);
    desenhar_arco(150, 115, 15, 0, Math.PI * 2, "cyan", 2, true);
    desenhar_arco(150, 115, 15, 0, Math.PI * 2, "blue", 2, false);

    desenhar_arco(70, 220, 15, 0, Math.PI * 2, "yellow", 2, true);
    desenhar_arco(70, 220, 15, 0, Math.PI * 2, "green", 2, false);
    desenhar_arco(220, 220, 15, 0, Math.PI * 2, "yellow", 2, true);
    desenhar_arco(220, 220, 15, 0, Math.PI * 2, "green", 2, false);
}

function desenhar_casa() {
    usar_canvas(ctxCasa);

    desenhar_quadrado(0, 0, 300, 300, "#87f5cc");
    desenhar_arco(225, 72, 38, 0, Math.PI * 2, "yellow", 1, true);

    desenhar_quadrado(38, 222, 262, 78, "#888888");

    ctxAtual.beginPath();
    ctxAtual.moveTo(0, 185);
    ctxAtual.quadraticCurveTo(38, 185, 38, 222);
    ctxAtual.lineTo(112, 222);
    ctxAtual.quadraticCurveTo(150, 222, 150, 300);
    ctxAtual.lineTo(0, 300);
    ctxAtual.closePath();
    ctxAtual.fillStyle = "#4285f4";
    ctxAtual.fill();

    desenhar_quadrado(112, 150, 75, 72, "#8b4513");
    desenhar_triangulo(112, 150, 150, 112, 187, 150, "tomato");
    desenhar_quadrado(120, 165, 23, 22, "#4db7ed");
    desenhar_quadrado(158, 165, 23, 22, "#4db7ed");
    desenhar_quadrado(143, 187, 24, 35, "#6b491f");

    desenhar_quadrado(38, 188, 15, 34, "#8b4513");
    desenhar_arco(45, 175, 28, 0, Math.PI * 2, "forestgreen", 1, true);

    desenhar_quadrado(263, 220, 15, 45, "#8b4513");
    desenhar_arco(270, 205, 28, 0, Math.PI * 2, "forestgreen", 1, true);
}

desenhar_modelo_canvas();
desenhar_casa();
