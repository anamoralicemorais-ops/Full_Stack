const express = require("express");
const path = require("path");

const app = express();
const porta = 80;
const raizSite = path.join(__dirname, "..", "..");

app.use(express.static(raizSite));

function enviarHome(req, res) {
    res.sendFile(path.join(raizSite, "Lab1", "index.html"));
}

function enviarProjetos(req, res) {
    res.sendFile(path.join(raizSite, "Lab2", "projects.html"));
}

app.get("/", enviarHome);
app.get("/Home.html", enviarHome);
app.get("/home.html", enviarHome);
app.get("/index.html", enviarHome);

app.get("/Project.html", enviarProjetos);
app.get("/project.html", enviarProjetos);
app.get("/Projects.html", enviarProjetos);
app.get("/projects.html", enviarProjetos);

app.listen(porta, "0.0.0.0", function() {
    console.log("Servidor rodando na porta " + porta);
    console.log("Home: http://localhost/Home.html");
    console.log("Projetos: http://localhost/Project.html");
});
