let numeroSorteado = Math.floor(Math.random() * 100);
let tentativas = 0;

function verificarPalpite() {
    const entrada = document.getElementById("palpite");
    const mensagem = document.getElementById("mensagem");
    const tentativasTexto = document.getElementById("tentativas");
    const palpite = Number(entrada.value);

    if (entrada.value === "" || palpite < 0 || palpite > 99) {
        mensagem.textContent = "Digite um número válido entre 0 e 99.";
        mensagem.style.setProperty("background-color", "red");
        mensagem.style.setProperty("color", "white");
        return;
    }

    tentativas++;
    tentativasTexto.textContent = "Tentativas: " + tentativas;

    if (palpite === numeroSorteado) {
        mensagem.textContent = "Parabéns! Você acertou o número " + numeroSorteado + ".";
        mensagem.style.setProperty("background-color", "green");
        mensagem.style.setProperty("color", "white");
    } else if (palpite > numeroSorteado) {
        mensagem.textContent = "Errou! O número sorteado é menor.";
        mensagem.style.setProperty("background-color", "red");
        mensagem.style.setProperty("color", "white");
    } else {
        mensagem.textContent = "Errou! O número sorteado é maior.";
        mensagem.style.setProperty("background-color", "red");
        mensagem.style.setProperty("color", "white");
    }

    entrada.value = "";
    entrada.focus();
}

function reiniciarJogo() {
    numeroSorteado = Math.floor(Math.random() * 100);
    tentativas = 0;

    document.getElementById("palpite").value = "";
    document.getElementById("tentativas").textContent = "Tentativas: 0";
    document.getElementById("mensagem").textContent = "Boa sorte!";
    document.getElementById("mensagem").style.setProperty("background-color", "transparent");
    document.getElementById("mensagem").style.setProperty("color", "black");
    document.getElementById("palpite").focus();
}
