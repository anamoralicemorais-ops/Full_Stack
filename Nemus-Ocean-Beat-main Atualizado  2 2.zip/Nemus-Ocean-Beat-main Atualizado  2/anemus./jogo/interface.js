let canvas = document.getElementById("canvas");
let ctx = canvas.getContext("2d");
let tamanho = 50

let pontuacao = 0;
let recorde = Number(localStorage.getItem("recordeAnemus")) || 0;
let novo_recorde = false;
let vida = 5;
let vida_max = 5;
let tela = "inicio";
let height = 900;
let width = 1880; 

let posx_polvo = 0;
let posy_polvo = 0;
let velx_polvo = 0;
let vely_polvo = 0;
let movimento_polvo = 0;
let vel_max_polvo = 15;
let animacao_polvo = 0;
let tamanho_polvo = 220;
let cor_botao = "#c45cff";
let flash_vermelho = 0;

function barra_vida(x,y){
    ctx.beginPath();
    ctx.fillStyle = "gray";
    //foi colocado 3 * tamanho pois o jogo tem tres vidas e vai aumentando de tamanho 
    ctx.fillRect(x+20,y+40,vida_max*tamanho,20);
    ctx.closePath();

    for(let i = 0; i < vida; i++){
        ctx.beginPath();
        ctx.fillStyle = "red";
        ctx.fillRect(x+20 + i*(tamanho),y+40,tamanho,20);
        ctx.closePath();
    }
}



function score(x,y){
    texto_direita("Score: " + pontuacao,"30px","black",y+30);
}

function hud(x,y){
    score(x,y)
    barra_vida(x,y)
}

function texto_direita(palavra, tamanho, cor, y){
    const x = ctx.measureText(palavra).width;
    texto(palavra, tamanho, cor, width - x, y)
}

function texto(palavra, tamanho, cor, x, y){
        ctx.beginPath();
        ctx.fillStyle = cor;
	    ctx.font = tamanho + " 'Press Start 2P'";
        ctx.fillText(palavra,x,y);
	    ctx.fill();
        ctx.closePath();
}

function texto_centro(palavra, tamanho, cor, x, y){
    ctx.font = tamanho + " 'Press Start 2P'";
    let largura_texto = ctx.measureText(palavra).width;
    texto(palavra, tamanho, cor, x - largura_texto/2, y);
}

function atualizarRecorde(){
    novo_recorde = false;
    if(pontuacao > recorde){
        recorde = pontuacao;
        novo_recorde = true;
        localStorage.setItem("recordeAnemus", recorde);
    }
}

function tocarMusica(){
    let musica = document.getElementById('musica');
    musica.currentTime = 0;
    musica.volume = 0.45;
    musica.play();
}

function pararMusica(){
    let musica = document.getElementById('musica');
    musica.pause();
    musica.currentTime = 0;
}

function desenharFlashVermelho(){
    if(flash_vermelho > 0){
        ctx.save();
        // o brilho diminui aos poucos para o flash sumir de forma suave.
        let brilho = flash_vermelho / 12;

        // aqui pegamos o centro do polvo para o flash aparecer perto dele,
        // e nao na tela inteira.
        let centro_x = posx_polvo + tamanho_polvo / 2;
        let centro_y = posy_polvo + tamanho_polvo / 2;

        // esse gradiente faz o vermelho ficar mais forte no meio
        // e transparente nas pontas, parecendo um flash pequeno.
        let flash = ctx.createRadialGradient(centro_x, centro_y, 20, centro_x, centro_y, 180);
        flash.addColorStop(0, "rgba(255, 0, 0, " + (0.45 * brilho) + ")");
        flash.addColorStop(0.45, "rgba(255, 0, 0, " + (0.22 * brilho) + ")");
        flash.addColorStop(1, "rgba(255, 0, 0, 0)");

        ctx.fillStyle = flash;
        ctx.fillRect(posx_polvo - 80, posy_polvo - 80, tamanho_polvo + 160, tamanho_polvo + 160);
        ctx.restore();

        // diminui o contador para o flash durar poucos frames.
        flash_vermelho--;
    }
}

function jogo(){
    if(tela == "inicio"){
        ctx.clearRect(0,0,width,height);
        ctx.drawImage(document.getElementById('fundo'),0,0,width,height);
        ctx.drawImage(document.getElementById('game'),(width - 500)/2, 40,500,500); 
        
        ctx.beginPath(); // retangulo
        ctx.fillStyle = cor_botao;
        ctx.fillRect((width-200)/2,(height+200)/2,200,50);
        ctx.closePath();
        
        texto("START ",'30px',"white",(width-150)/2,(height+280)/2)
        
    }
    else if(tela == "jogo"){
        ctx.clearRect(0,0,width,height);
        //ctx.drawImage(document.getElementById('fundo_mar'),0,0,width,height);
        hud(width-300,20);
        fundo();
        atualizarAnimais();
        desenharAnimais();
        hud(width-300,20);
        polvo();
        desenharFlashVermelho();
        posy_polvo = Math.max(0,Math.min(posy_polvo + vely_polvo, height-300));
        if( vida==0 ){
            atualizarRecorde();
            pararMusica();
            tela="fim";
        }
        // ctx.drawImage(document.getElementById('polvo1'),0,0,100,100);
        // pontuacao++;
        // jogo

    }
    else if(tela == "fim"){
        ctx.clearRect(0,0,width,height);
        ctx.drawImage(document.getElementById('fundo'),0,0,width,height);
        ctx.drawImage(document.getElementById('gameover'),(width - 430)/2, 90,430,323); 
        
        let fim_score_y = (height+40)/2;
        let fim_novo_recorde_y = (height+150)/2;
        let fim_recorde_y = (height+260)/2;
        let fim_botao_y = (height+350)/2;

        ctx.beginPath(); // retangulo
        ctx.fillStyle = cor_botao;
        ctx.fillRect((width-400)/2,fim_botao_y,400,50);
        ctx.closePath();

        texto_centro("Your Score: " + pontuacao,"30px","black",width/2,fim_score_y)
        if(novo_recorde){
            texto_centro("New Record!","25px","#ff2ebd",width/2,fim_novo_recorde_y)
        }
        texto_centro("Record: " + recorde,"25px","black",width/2,fim_recorde_y)
        texto_centro("Play again","30px","white",width/2,fim_botao_y + 35)
        
    }
    requestAnimationFrame(jogo);
}

jogo()

// Verifica se o usuario clicou no botao de começar um novo jogo
document.addEventListener("click",  function(evento){ //auxilio do chat para a criaçao do botao
    rect = canvas.getBoundingClientRect();
    let posx = evento.clientX - rect.left;
    let posy = evento.clientY - rect.top;
    if(posx >= (width-200)/2               
    && posy >= (height+200)/2
    && posx <= (width-200)/2 + 200
    && posy <= (height+200)/2 + 50
    && tela == "inicio"){
        tela = "jogo";
        pontuacao=0
        novo_recorde = false;
        vida=vida_max
        vely_polvo = 0;
        movimento_polvo = 0;
        animais = [];
        tocarMusica();
    }

    else if(posx >= (width-400)/2               
    && posy >= (height+350)/2
    && posx <= (width-400)/2 + 400
    && posy <= (height+350)/2 + 50
    && tela == "fim"){
        tela = "jogo";
        pontuacao=0
        novo_recorde = false;
        vida=vida_max
        vely_polvo = 0;
        movimento_polvo = 0;
        animais = [];
        tocarMusica();
    }
    // console.log(tela)
});

document.addEventListener("keydown", function(event) {

    if (tela === "jogo") {
        console.log(`Key pressed: ${event.key}`);
        if (event.key === "ArrowDown" && vely_polvo < vel_max_polvo) {
            vely_polvo += vel_max_polvo;
            movimento_polvo = 3;
        }else if (event.key === "ArrowUp" && vely_polvo > -vel_max_polvo) {
            vely_polvo -= vel_max_polvo;
            movimento_polvo = 4;
        }
    }
});

document.addEventListener("keyup", function(event) {
    if (tela === "jogo") {
        if (event.key === "ArrowDown" && vely_polvo > -vel_max_polvo) {
            vely_polvo -= vel_max_polvo;
            movimento_polvo = 3;
        }else if (event.key === "ArrowUp" && vely_polvo < vel_max_polvo) {
            vely_polvo += vel_max_polvo;
            movimento_polvo = 4;
        }
        if (event.key === "ArrowRight" || event.key === "ArrowDown" || event.key === "ArrowUp" || event.key === "ArrowLeft") {
            movimento_polvo = 0;
        }
    }
});

function circulo(x,y,raio,cor){
    ctx.beginPath();
    ctx.fillStyle=cor;
    ctx.arc(x,y,raio,0*Math.PI,2*Math.PI);
    ctx.fill();
    ctx.closePath()
}


function meio_circulo(x,y,raio,cor){
    ctx.beginPath();
    ctx.fillStyle=cor;
    ctx.arc(x,y,raio,0*Math.PI,Math.PI);
    ctx.fill();
    ctx.closePath()
}


function retangulo(x,y,largura,altura,cor){
    ctx.beginPath();
    ctx.fillStyle=cor;
    ctx.fillRect(x,y,largura,altura);
    ctx.fill();
    ctx.closePath();
}

function alga(x, alturas, cores,quantidade){
    const y = height-220;
    const largura = 15;
    // console.log(cores)
    // console.log(alturas)
    for(let i = 0; i < quantidade; i++){
        retangulo(x + (i*largura),y + (200 - alturas[i]),largura, alturas[i], cores[i]);
    }
}

function polvo(id){
    animacao_polvo += 0.05;
    let nome_imagem = 'polvo' + String(movimento_polvo);
    let balanco = 0;

    if(movimento_polvo == 0){
        balanco = Math.sin(animacao_polvo) * 10;
        if(Math.floor(animacao_polvo * 1) % 2 == 0){
            nome_imagem = 'polvo1';
        }
    }

    ctx.drawImage(document.getElementById(nome_imagem),posx_polvo, posy_polvo + balanco,tamanho_polvo,tamanho_polvo); 
    // ctx.drawImage(document.getElementById('polvo2'),(width - 100)/2, (height - 200)/3,300,300); 

}

function aguaviva(x,y,tamanho,){
    let raio = tamanho/2; 
    tentaculos = [120/200,100/200,200/200,150/200,40/200]
    ctx.beginPath();
    ctx.fillStyle='#80b0eeff';
    ctx.arc(x+raio,y+raio,raio,1*Math.PI,0*Math.PI);
    ctx.fill();
    ctx.closePath();
    let borda = 20/6;
    let largura_tentaculo = (tamanho - 20) / 5;

    for(let i = 1; i <= 5; i++){
        retangulo(x + (borda)*i + largura_tentaculo*(i-1),y+raio,largura_tentaculo, tentaculos[i-1] * raio, '#e39af3ff');
    }
}

function fundo(){


    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle='lightblue';
    ctx.fillRect(0,0,width,height);
    ctx.fill();
    ctx.closePath();

    alga(30,[120,100,200,150,40],['green','darkgreen','#4BB748','#0B8F44','green'],5);
    alga(700,[160,70,160,120,120],['#2EAF4A','#20532A','#7CC472','#0B8F44','#A9D5A0'],5);
    alga(900,[85,110,60,150,75],['#4BB748','#20532A','#7CC472','#157E43','#20532A'],5);
    alga(1300,[120,150,130,80,70],['green','#4BB748','#0B8F44','#0F703A','#A9D5A0'],5);
    alga(1500,[120,150,130,80,70],['green','#4BB748','#0B8F44','#0F703A','#A9D5A0'],5);





    //  corpo da alga viva 2
    ctx.beginPath();
    ctx.fillStyle='#91569E';
    ctx.arc(998,200,55,1*Math.PI,0*Math.PI);
    ctx.fill();
    ctx.closePath();

    // tentáculo da água viva 2
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle='#D980CD';
    ctx.fillRect(990,200,8,70);
    ctx.fill();
    ctx.closePath();

    // tentáculo da água viva 2
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle='#D980CD';
    ctx.fillRect(970,200,8,40);
    ctx.fill();
    ctx.closePath();

    // tentáculo da água viva 2
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle='#D980CD';
    ctx.fillRect(1008,200,8,60);
    ctx.fill();
    ctx.closePath();

    // tentáculo da água viva 2
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle='#D980CD';
    ctx.fillRect(955,200,8,90);
    ctx.fill();
    ctx.closePath();

    // tentáculo da água viva 2
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle='#D980CD';
    ctx.fillRect(1028,200,8,90);
    ctx.fill();
    ctx.closePath();

    // casca da tartaruga 
    ctx.beginPath();
    ctx.fillStyle='#CFD597';
    ctx.arc(600,700,80,1*Math.PI,0*Math.PI);
    ctx.fill();
    ctx.closePath();

    // escama da casca da tartaruga 
    ctx.beginPath();
    ctx.fillStyle='#C19256';
    ctx.arc(655,700,15,1*Math.PI,0*Math.PI);
    ctx.fill();
    ctx.closePath();

    // escama da casca da tartaruga 
    ctx.beginPath();
    ctx.fillStyle='#C19256';
    ctx.arc(620,640,15,0*Math.PI,2*Math.PI);
    ctx.fill();
    ctx.closePath();

    // escama da casca da tartaruga 
    ctx.beginPath();
    ctx.fillStyle='#C19256';
    ctx.arc(640,670,15,0*Math.PI,2*Math.PI);
    ctx.fill();
    ctx.closePath();

    // escama da casca da tartaruga 
    ctx.beginPath();
    ctx.fillStyle='#C19256';
    ctx.arc(606,670,15,0*Math.PI,2*Math.PI);
    ctx.fill();
    ctx.closePath();

    // escama da casca da tartaruga 
    ctx.beginPath();
    ctx.fillStyle='#C19256';
    ctx.arc(556,655,15,0*Math.PI,2*Math.PI);
    ctx.fill();
    ctx.closePath();

    // escama da casca da tartaruga 
    ctx.beginPath();
    ctx.fillStyle='#C19256';
    ctx.arc(563,685,15,0*Math.PI,2*Math.PI);
    ctx.fill();
    ctx.closePath();

    // escama da casca da tartaruga 
    ctx.beginPath();
    ctx.fillStyle='#C19256';
    ctx.arc(585,640,15,0*Math.PI,2*Math.PI);
    ctx.fill();
    ctx.closePath();


    // escama da casca da tartaruga 
    ctx.beginPath();
    ctx.fillStyle='#C19256';
    ctx.arc(534,700,15,1*Math.PI,0*Math.PI);
    ctx.fill();
    ctx.closePath();

    // escama da casca da tartaruga 
    ctx.beginPath();
    ctx.fillStyle='#C19256';
    ctx.arc(590,700,15,1*Math.PI,0*Math.PI);
    ctx.fill();
    ctx.closePath();

    // escama da casca da tartaruga 
    ctx.beginPath();
    ctx.fillStyle='#C19256';
    ctx.arc(622,700,15,1*Math.PI,0*Math.PI);
    ctx.fill();
    ctx.closePath();



    // cabeça da tartaruga
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= '#87A449';
    ctx.arc(690,675,25,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();

    // olho da tartaruga
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= 'black';
    ctx.arc(696,665,6,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();


    // boca da tartaruga 
    ctx.beginPath();
    ctx.lineWidth=1;
    ctx.strokeStyle='black';
    ctx.arc(708,678,5,0*Math.PI,1*Math.PI);
    ctx.stroke();
    ctx.closePath();


    // bolha da tartaruga
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= '#C7EAFD';
    ctx.arc(734,650,10,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();

    // bolha da tartaruga
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= '#C7EAFD';
    ctx.arc(745,620,15,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();

    // bolha da tartaruga
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= '#C7EAFD';
    ctx.arc(750,580,20,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();

    // pata da tartaruga 
    ctx.beginPath();
    ctx.lineWidth=1;
    ctx.fillStyle= '#87A449';
    ctx.arc(650,700,20,0*Math.PI,1*Math.PI);
    ctx.fill();
    ctx.closePath();


    // pata da tartaruga 
    ctx.beginPath();
    ctx.lineWidth=1;
    ctx.fillStyle= '#87A449';
    ctx.arc(580,700,20,0*Math.PI,1*Math.PI);
    ctx.fill();
    ctx.closePath();

    // rabo da tartaruga
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= '#87A449';
    ctx.fillRect(500,690,20,10);
    ctx.fill();
    ctx.closePath();


    // areia 
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= '#F6E29D';
    ctx.fillRect(0,height-20,width,20);
    ctx.fill();
    ctx.closePath();


    // corpo do porco espinho
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= '#F9A11D';
    ctx.arc(340,115,37,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();


    // olho do porco espinho
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= 'black';
    ctx.arc(315,108,6,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();

    // boca do porco espinho
    ctx.beginPath();
    ctx.lineWidth=1;
    ctx.strokeStyle='black';
    ctx.arc(310,126,5,0*Math.PI,1*Math.PI);
    ctx.stroke();
    ctx.closePath();


    // espinho do porco espinho 
    ctx.beginPath();
    ctx.lineWidth=5;
    ctx.strokeStyle='#f9a11dac';
    ctx.moveTo(330,120);
    ctx.lineTo(310,150);
    ctx.stroke();
    ctx.closePath();
    
    // espinho do porco espinho 
    ctx.beginPath();
    ctx.lineWidth=5;
    ctx.strokeStyle='#f9a11dac';
    ctx.moveTo(380,90);
    ctx.lineTo(320,100);
    ctx.stroke();
    ctx.closePath();
    
    // espinho do porco espinho 
    ctx.beginPath();
    ctx.lineWidth=5;
    ctx.strokeStyle='#f9a11dac';
    ctx.moveTo(360,120);
    ctx.lineTo(380,140);
    ctx.stroke();
    ctx.closePath();
    
    
    // espinho do porco espinho 
    ctx.beginPath();
    ctx.lineWidth=5;
    ctx.strokeStyle='#f9a11dac';
    ctx.moveTo(314,70);
    ctx.lineTo(320,100);
    ctx.stroke();
    ctx.closePath();
    

    // espinho do porco espinho 
    ctx.beginPath();
    ctx.lineWidth=5;
    ctx.strokeStyle='#f9a11dac';
    ctx.moveTo(354,66);
    ctx.lineTo(350,100);
    ctx.stroke();
    ctx.closePath();


    // espinho do porco espinho 
    ctx.beginPath();
    ctx.lineWidth=5;
    ctx.strokeStyle='#f9a11dac';
    ctx.moveTo(354,120);
    ctx.lineTo(340,160);
    ctx.stroke();
    ctx.closePath();

    // bolha do porco espinho
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= '#C7EAFD';
    ctx.arc(278,120,10,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();

    // bolha do porco espinho
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= '#C7EAFD';
    ctx.arc(268,90,15,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();


    // bolha do porco espinho
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= '#C7EAFD';
    ctx.arc(258,53,20,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();


    // corpo do porco espinho
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= '#F9A11D';
    ctx.arc(1190,445,42,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();

    // olho do porco espinho
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= 'black';
    ctx.arc(1215,440,8,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();


    // boca do porco espinho
    ctx.beginPath();
    ctx.lineWidth=1;
    ctx.strokeStyle='black';
    ctx.arc(1220,460,5,0*Math.PI,1*Math.PI);
    ctx.stroke();
    ctx.closePath();

    // espinho do porco espinho 
    ctx.beginPath();
    ctx.lineWidth=5;
    ctx.strokeStyle='#f9a11dac';
    ctx.moveTo(1148,480);
    ctx.lineTo(1170,440);
    ctx.stroke();
    ctx.closePath();

    // espinho do porco espinho 
    ctx.beginPath();
    ctx.lineWidth=5;
    ctx.strokeStyle='#f9a11dac';
    ctx.moveTo(1148,406);
    ctx.lineTo(1170,420);
    ctx.stroke();
    ctx.closePath();

    
    // espinho do porco espinho 
    ctx.beginPath();
    ctx.lineWidth=5;
    ctx.strokeStyle='#f9a11dac';
    ctx.moveTo(1188,500); 
    ctx.lineTo(1190,480); 
    ctx.stroke();
    ctx.closePath();


    // espinho do porco espinho 
    ctx.beginPath();
    ctx.lineWidth=5;
    ctx.strokeStyle='#f9a11dac';
    ctx.moveTo(1198,390); 
    ctx.lineTo(1190,480); 
    ctx.stroke();
    ctx.closePath();

    // espinho do porco espinho 
    ctx.beginPath();
    ctx.lineWidth=5;
    ctx.strokeStyle='#f9a11dac';
    ctx.moveTo(1130,440); 
    ctx.lineTo(1150,440); 
    ctx.stroke();
    ctx.closePath();

    // bolha do porco espinho
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= '#C7EAFD';
    ctx.arc(1260,460,10,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();

    // bolha do porco espinho
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= '#C7EAFD';
    ctx.arc(1270,420,15,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();


    // bolha do porco espinho
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.fillStyle= '#C7EAFD';   
    ctx.arc(1272,373,20,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();

}

// animais vindo ao polvo
// referencias https://youtu.be/r9buAwVBDhA?si=im16430X3Dm3ZYYI
let animais = [];
let tempoAnimal = 0;

const tipos = [
    {
        tipo:"normal",
        cor:"orange"
    },
    {
        tipo:"vida",
        cor:"gold"
    },
    {
        tipo:"perde vida"
        // cor:"purple"
    },
    {
        tipo:"ganha_pontuacao",
        cor:'cyan'
        
    }
]  
function criarAnimal() {
    let indice = Math.random(); // [ 0 - 1 ]
    if(indice < 0.1) indice = 1; 
    else if(indice < 0.4) indice = 2; 
    else if(indice < 0.5) indice = 3;
    else indice = 0;
    let velocidade_y = Math.random();
    if(velocidade_y < 0.5) velocidade_y = 0;
    else velocidade_y = 5 + velocidade_y * 5; 
    animais.push({
        x: width + 50,
        y: Math.random() * (height - 350) + 100,
        largura: 70,
        altura: 45,
        vel_x: 5 + Math.random()*8,
        vel_y: velocidade_y,
        animacao: Math.random() * Math.PI * 2,
        cor: tipos[indice].cor,
        tipo: tipos[indice].tipo
    });
}

function atualizarAnimais() {
    tempoAnimal++;

    if (tempoAnimal > 75) {
        criarAnimal();
        tempoAnimal = 0;
    }

    for (let i = animais.length - 1; i >= 0; i--) {
        if(animais[i].y - animais[i].vel_y < 0
        || animais[i].y - animais[i].vel_y + animais[i].altura > height){
            animais[i].vel_y *= -1;
        }
        animais[i].x -= animais[i].vel_x;
        animais[i].y -= animais[i].vel_y; 
        animais[i].animacao += 0.2;
        if(pegouAnimal(animais[i])) {
            if(animais[i].tipo == "perde vida"){
                vida--
                flash_vermelho = 12;
                animais.splice(i, 1);
            }
        } else if (animais[i].x + animais[i].largura < 0) {
            if(animais[i].tipo != 'perde vida') vida--;
            animais.splice(i, 1);
        }
    }
}

// animacao dos peixes - mexer a caudinha
// referencia https://youtu.be/glnSi51koBQ?si=tv-U9CinZwWh6bHB
function peixe(x,y,largura,altura,cor,animacao){
    let balanco = Math.sin(animacao) * 4;
    let cauda = Math.sin(animacao * 2) * 10;

    ctx.fillStyle = cor;
    ctx.fillRect(x, y + balanco, largura, altura);

    // cauda
    ctx.beginPath();
    ctx.moveTo(x + largura, y + balanco + altura / 2);
    ctx.lineTo(x + largura + 25 + cauda, y + balanco);
    ctx.lineTo(x + largura + 25 - cauda, y + balanco + altura);
    ctx.closePath();
    ctx.fill();

    // olho
    ctx.fillStyle = "black";
    ctx.beginPath();
    ctx.arc(x + 15, y + balanco + 15, 5, 0, Math.PI * 2);
    ctx.fill();
}
// peixe
function desenharAnimais() {
    for (let a of animais) {
        if(a.tipo == "perde vida") aguaviva(a.x,a.y,a.largura,5);
        else peixe(a.x,a.y,a.largura,a.altura,a.cor,a.animacao)
    }
}

// colisao com o anemus - barra de espaço
// referencia https://youtu.be/k887x45_R4w?si=cZPziPCzQYG3ouJp
function pegouAnimal(a) {
    return (
        a.x < posx_polvo + 250 &&
        a.x + a.largura > posx_polvo &&
        a.y < posy_polvo + 250 &&
        a.y + a.altura > posy_polvo
    );
}

document.addEventListener("keydown", function(event) {
    if (tela === "jogo" && event.code === "Space") {

        for (let i = animais.length - 1; i >= 0; i--) {
            if (pegouAnimal(animais[i])) {
                if(animais[i].tipo == 'normal'){
                    pontuacao++;
                }
                else if(animais[i].tipo=="vida"){
                    if(vida < vida_max) vida++;
                }
                else if(animais[i].tipo=="ganha_pontuacao"){
                    pontuacao+=10;
                }
                // bater no peixe antes de deletar as informações do peixe 
                animais.splice(i, 1);
                break;
                
            }
            
        }
    }
});

